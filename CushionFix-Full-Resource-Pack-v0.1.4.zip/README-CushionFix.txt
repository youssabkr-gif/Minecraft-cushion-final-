CushionFix Full Resource Pack

Contents
- Original 16 cushion item textures and 16 original 64x64 world/entity textures copied from the supplied CushionBackport Fabric mod.
- Original item model definitions and language/sound assets.
- Separate 3D cuboid world models for all 16 colors.
- CustomModelData 5101-5116 routing for the CushionFix plugin carrier PAPER and ViaBackwards carpet fallback items.
- Legacy model overrides under assets/minecraft/models/item and modern item definitions under assets/minecraft/items.

Install
1. Upload this ZIP to a direct-download host (GitHub raw is suitable).
2. Put its direct URL and SHA-1 into server.properties, or configure the plugin's resource-pack section. Do not enable both delivery methods at once.
3. The plugin source currently uses CustomModelData 5101-5116. Keep these values in sync if you change the plugin.

Important compatibility notes
- pack.mcmeta uses pack_format 75, targeting the 1.21.11 resource-pack format. Newer clients may display a compatibility warning; this does not prove the pack will fail, but test on each target client.
- This pack is designed for the CushionFix 0.1.4 source provided in this conversation. It is not a substitute for the plugin.
- The separate world model is a 16x4x16 cuboid. The Paper plugin's ItemDisplay transformation, position, and yaw still control its placement. Test in-game before public deployment.
- The pack alone does not add the Cushion block/item to Minecraft.
