CushionFix Java Resource Pack — compatibility build

Supported client range (with the matching updated CushionFix plugin):
- Java Edition 1.19.4 through 26.3
- 1.19.4–1.21.3 use the legacy CustomModelData model override.
- 1.21.4–26.3 use the modern item-model overlay.

This pack alone is not enough with the old plugin source. The plugin must set
CustomModelData on PAPER instead of the 1.21.4+ item_model component. Use the
matching source archive provided separately.

Clients below 1.19.4 are not supported by this plugin design because its fake
display and interaction entities were added in 1.19.4. Bedrock clients are not
included in this compatibility target.

CustomModelData mapping:
- white: 5101
- orange: 5102
- magenta: 5103
- light_blue: 5104
- yellow: 5105
- lime: 5106
- pink: 5107
- gray: 5108
- light_gray: 5109
- cyan: 5110
- purple: 5111
- blue: 5112
- brown: 5113
- green: 5114
- red: 5115
- black: 5116
