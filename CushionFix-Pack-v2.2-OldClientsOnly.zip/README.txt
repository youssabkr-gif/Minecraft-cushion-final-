CushionFix vanilla-shape pack v2

Changes:
- Cushion is now a 16x4 slab with a small raised centre button, soft edge shading and quilted fold lines (matches the 26.3 reference).
- Models now inherit minecraft:block/block and define their own 'display' transforms, so the inventory / hotbar / hand / dropped-item / item-frame icon is a proper 3D cushion (before, there was no gui transform so the icon showed edge-on as a thin line).
- Textures are 32x32 atlases (top, side, bottom, button) per colour.

Pair with CushionFix plugin v0.1.1 (display-y-offset default 0.5 so the display entity sits on the floor instead of half-buried).

v2.1: modern *_cushion item definitions now fall back to the CushionFix cushion model (not a carpet), so an untagged cushion item never shows as a carpet.

v2.2: REMOVED the modern *_cushion item definitions. 26.3 clients keep the vanilla cushion model/icon untouched.
The pack now only affects the *_carpet (and paper) items that older clients receive from ViaBackwards in place of cushions, i.e. only old-version players see the converted cushion look.
